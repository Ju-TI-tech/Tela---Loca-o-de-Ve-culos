import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.border.BevelBorder;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;

public class tela01 extends JFrame {

	private JPanel contentPane;
	private JTextField textEndereco;
	private JTextField textRG;
	private JLabel lblDigiteSeuCpf;
	private JTextField textCPF;
	private JTextField textNome;
	private JRadioButton rdbtnNewRadioButton;
	private JRadioButton rdbtnNewRadioButton_1;
	private JLabel lblNewLabel_3;
	private JLabel lblNewLabel_4;
	private JTextField textEmail;
	private JLabel lblNewLabel_5;
	private JTextField textDataNascimento;
	private JLabel lblNewLabel_6;
	private JTextField textNTelefone;
	private JPasswordField txtSenha;
	private JPasswordField txtConfirmeSenha;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					tela01 frame = new tela01();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public tela01() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 315);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblCadastroDoUsurio = new JLabel("Cadastro do Usu\u00E1rio");
		lblCadastroDoUsurio.setBounds(5, 5, 425, 21);
		lblCadastroDoUsurio.setHorizontalAlignment(SwingConstants.CENTER);
		lblCadastroDoUsurio.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 15));
		contentPane.add(lblCadastroDoUsurio);
		
		textEndereco = new JTextField();
		textEndereco.setBounds(10, 192, 159, 20);
		contentPane.add(textEndereco);
		textEndereco.setColumns(10);
		
		JLabel lblDigiteSeuNome = new JLabel("Digite seu nome:");
		lblDigiteSeuNome.setFont(new Font("Arial", Font.PLAIN, 11));
		lblDigiteSeuNome.setBounds(15, 37, 86, 14);
		contentPane.add(lblDigiteSeuNome);
		
		JLabel lblDataDeNascimento = new JLabel("Data seu RG:");
		lblDataDeNascimento.setFont(new Font("Arial", Font.PLAIN, 11));
		lblDataDeNascimento.setBounds(179, 37, 108, 14);
		contentPane.add(lblDataDeNascimento);
		
		textRG = new JTextField();
		textRG.setBounds(179, 51, 113, 20);
		contentPane.add(textRG);
		textRG.setColumns(10);
		
		lblDigiteSeuCpf = new JLabel("Digite seu CPF:");
		lblDigiteSeuCpf.setFont(new Font("Arial", Font.PLAIN, 11));
		lblDigiteSeuCpf.setBounds(302, 37, 86, 14);
		contentPane.add(lblDigiteSeuCpf);
		
		textCPF = new JTextField();
		textCPF.setBounds(302, 51, 113, 20);
		contentPane.add(textCPF);
		textCPF.setColumns(10);
		
		textNome = new JTextField();
		textNome.setBounds(10, 51, 159, 20);
		contentPane.add(textNome);
		textNome.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Digite seu E-mail:");
		lblNewLabel.setFont(new Font("Arial", Font.PLAIN, 11));
		lblNewLabel.setBounds(10, 82, 164, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Digite sua senha:");
		lblNewLabel_1.setFont(new Font("Arial", Font.PLAIN, 11));
		lblNewLabel_1.setBounds(179, 82, 113, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Confirme sua senha:");
		lblNewLabel_2.setFont(new Font("Arial", Font.PLAIN, 11));
		lblNewLabel_2.setBounds(302, 82, 113, 14);
		contentPane.add(lblNewLabel_2);
		
		JPanel panel = new JPanel();
		panel.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		panel.setBackground(Color.WHITE);
		panel.setBounds(179, 129, 236, 109);
		contentPane.add(panel);
		panel.setLayout(null);
		
		rdbtnNewRadioButton = new JRadioButton("Sim");
		rdbtnNewRadioButton.setBounds(17, 32, 202, 21);
		rdbtnNewRadioButton.setFont(new Font("Arial", Font.PLAIN, 11));
		panel.add(rdbtnNewRadioButton);
		
		rdbtnNewRadioButton_1 = new JRadioButton("N\u00E3o");
		rdbtnNewRadioButton_1.setFont(new Font("Arial", Font.PLAIN, 11));
		rdbtnNewRadioButton_1.setBounds(17, 66, 202, 23);
		panel.add(rdbtnNewRadioButton_1);
		
		lblNewLabel_3 = new JLabel("Possui carteira de habilita\u00E7\u00E3o?");
		lblNewLabel_3.setBounds(17, 11, 202, 14);
		panel.add(lblNewLabel_3);
		
		lblNewLabel_4 = new JLabel("Digite seu data de nascimento:");
		lblNewLabel_4.setFont(new Font("Arial", Font.PLAIN, 11));
		lblNewLabel_4.setBounds(10, 129, 159, 14);
		contentPane.add(lblNewLabel_4);
		
		textEmail = new JTextField();
		textEmail.setBounds(10, 98, 159, 20);
		contentPane.add(textEmail);
		textEmail.setColumns(10);
		
		lblNewLabel_5 = new JLabel("Digite seu endere\u00E7o");
		lblNewLabel_5.setFont(new Font("Arial", Font.PLAIN, 11));
		lblNewLabel_5.setBounds(10, 178, 159, 14);
		contentPane.add(lblNewLabel_5);
		
		textDataNascimento = new JTextField();
		textDataNascimento.setBounds(10, 147, 159, 20);
		contentPane.add(textDataNascimento);
		textDataNascimento.setColumns(10);
		
		lblNewLabel_6 = new JLabel("Digite seu n\u00FAmero de telefone:");
		lblNewLabel_6.setFont(new Font("Arial", Font.PLAIN, 11));
		lblNewLabel_6.setBounds(10, 224, 183, 14);
		contentPane.add(lblNewLabel_6);
		
		textNTelefone = new JTextField();
		textNTelefone.setBounds(10, 241, 159, 20);
		contentPane.add(textNTelefone);
		textNTelefone.setColumns(10);
		
		JButton btnNewButton = new JButton("Salvar e Entrar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				

				new tela02 () .setVisible(true);
				
						String senha = txtSenha.getText();
						String confirmeSenha = txtConfirmeSenha.getText();
						
						if(senha.equals(confirmeSenha)) {
							JOptionPane.showMessageDialog(null, "Confirma��o de senha correta! Clique em OK para entrar no site");
						}else {
							JOptionPane.showMessageDialog(null, "A Confirma��o da senha n�o confere com a senha digitada! "
									+ "Por favor, coloque as senha iguais para conseguir entrar no site");
						}
					}
				});
				
		btnNewButton.setBounds(179, 240, 236, 23);
		contentPane.add(btnNewButton);
		
		txtSenha = new JPasswordField();
		txtSenha.setBounds(179, 98, 113, 20);
		contentPane.add(txtSenha);
		
		txtConfirmeSenha = new JPasswordField();
		txtConfirmeSenha.setBounds(302, 98, 113, 20);
		contentPane.add(txtConfirmeSenha);
	}
}




