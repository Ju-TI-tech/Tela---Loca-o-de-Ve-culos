import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class tela04 extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				
				try {
					tela04 frame = new tela04();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public tela04() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 264);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblFormaDePagamento = new JLabel("Forma de Pagamento");
		lblFormaDePagamento.setBounds(5, 5, 425, 21);
		lblFormaDePagamento.setHorizontalAlignment(SwingConstants.CENTER);
		lblFormaDePagamento.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 15));
		contentPane.add(lblFormaDePagamento);
		
		JLabel lblNewLabel = new JLabel("Escolha sua forma de pagamento:");
		lblNewLabel.setBounds(27, 37, 168, 14);
		contentPane.add(lblNewLabel);
		
		JRadioButton rdbtnNewRadioButton = new JRadioButton("Cart\u00E3o de cr\u00E9dito");
		rdbtnNewRadioButton.setBounds(24, 58, 125, 23);
		contentPane.add(rdbtnNewRadioButton);
		
		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("Cart\u00E3o de d\u00E9bito");
		rdbtnNewRadioButton_1.setBounds(25, 82, 170, 23);
		contentPane.add(rdbtnNewRadioButton_1);
		
		JLabel lblNewLabel_1 = new JLabel("N\u00FAmero do Cart\u00E3o:");
		lblNewLabel_1.setBounds(27, 117, 156, 14);
		contentPane.add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setBounds(27, 135, 156, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Nome do Cart\u00E3o:");
		lblNewLabel_2.setBounds(24, 168, 95, 14);
		contentPane.add(lblNewLabel_2);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(27, 187, 136, 20);
		contentPane.add(textField_1);
		
		JLabel lblNewLabel_3 = new JLabel("Data de Expira\u00E7\u00E3o:");
		lblNewLabel_3.setBounds(229, 117, 136, 14);
		contentPane.add(lblNewLabel_3);
		
		

		
		JButton btnSair = new JButton("Confirmar e Sair");
		btnSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				JOptionPane.showMessageDialog(null, "Pagamento confirmado");
				
				System.exit(0);
			}
		});
		btnSair.setBounds(229, 71, 156, 23);
		contentPane.add(btnSair);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(229, 135, 156, 20);
		contentPane.add(textField_2);
		
		JLabel lblNewLabel_4 = new JLabel("C\u00F3digo de Seguran\u00E7a:");
		lblNewLabel_4.setBounds(229, 168, 175, 14);
		contentPane.add(lblNewLabel_4);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(229, 187, 156, 20);
		contentPane.add(textField_3);
		
		
		
		JButton btnNewButton = new JButton("Limpar");
		btnNewButton.addActionListener(new ActionListener() {
			    public void actionPerformed(ActionEvent e){
			    	textField.setText(null);
			    	textField_1.setText(null);
			    	textField_2.setText(null);
			    	textField_3.setText(null);
			        
			    }
		});
		btnNewButton.setBounds(229, 37, 156, 23);
		contentPane.add(btnNewButton);
		
	
	}

}