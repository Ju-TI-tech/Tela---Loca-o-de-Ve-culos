import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.border.BevelBorder;
import javax.swing.ImageIcon;

public class tela02 extends JFrame {

	private JPanel JPanel;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_4;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_5;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					tela02 frame = new tela02();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public tela02() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 330);
		JPanel = new JPanel();
		JPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(JPanel);
		JPanel.setLayout(null);
		
		JLabel lblModeloVeiculo = new JLabel("Escolha seu Ve\u00EDculo");
		lblModeloVeiculo.setHorizontalAlignment(SwingConstants.CENTER);
		lblModeloVeiculo.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 15));
		lblModeloVeiculo.setBounds(0, 0, 438, 31);
		JPanel.add(lblModeloVeiculo);
		
		JLabel lblNewLabel = new JLabel("Modelo:");
		lblNewLabel.setBounds(16, 61, 46, 14);
		JPanel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Ano:");
		lblNewLabel_1.setBounds(16, 86, 46, 14);
		JPanel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Cor:");
		lblNewLabel_2.setBounds(16, 117, 46, 14);
		JPanel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_5 = new JLabel("");
		lblNewLabel_5.setBounds(190, 139, 74, 14);
		JPanel.add(lblNewLabel_5);
		
		textField = new JTextField();
		textField.setBounds(72, 58, 86, 20);
		JPanel.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(72, 114, 86, 20);
		JPanel.add(textField_1);
		textField_1.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBounds(72, 86, 86, 20);
		JPanel.add(textField_4);
		textField_4.setColumns(10);
		
		JButton btnNewButton = new JButton("Pedir Carro");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new tela03 () .setVisible(true);
				}
		});
		btnNewButton.setBounds(175, 257, 106, 23);
		JPanel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Pedir Moto");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new tela3moto () .setVisible(true);
			}
		});
		btnNewButton_1.setBounds(311, 257, 96, 23);
		JPanel.add(btnNewButton_1);
		
		JPanel panel = new JPanel();
		panel.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		panel.setBackground(Color.WHITE);
		panel.setBounds(176, 35, 234, 96);
		JPanel.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_6 = new JLabel("                 Quantidade de Lugares");
		lblNewLabel_6.setBounds(6, 7, 222, 14);
		panel.add(lblNewLabel_6);
		
		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("2 Lugares");
		rdbtnNewRadioButton_1.setBounds(6, 28, 100, 25);
		panel.add(rdbtnNewRadioButton_1);
		
		JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("5 Lugares");
		rdbtnNewRadioButton_2.setBounds(6, 56, 100, 23);
		panel.add(rdbtnNewRadioButton_2);
		
		JRadioButton rdbtnNewRadioButton_3 = new JRadioButton("7 Lugares");
		rdbtnNewRadioButton_3.setBounds(128, 29, 100, 23);
		panel.add(rdbtnNewRadioButton_3);
		
		JRadioButton rdbtnNewRadioButton_4 = new JRadioButton("9 Lugares");
		rdbtnNewRadioButton_4.setBounds(128, 56, 100, 23);
		panel.add(rdbtnNewRadioButton_4);
		
		JLabel lblNewLabel_3 = new JLabel("Carros");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_3.setBounds(72, 28, 136, 27);
		JPanel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Motos");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_4.setBounds(82, 149, 74, 14);
		JPanel.add(lblNewLabel_4);
		
		JLabel lblNewLabel_7 = new JLabel("Modelo:");
		lblNewLabel_7.setBounds(16, 177, 46, 14);
		JPanel.add(lblNewLabel_7);
		
		textField_2 = new JTextField();
		textField_2.setBounds(72, 174, 86, 20);
		JPanel.add(textField_2);
		textField_2.setColumns(10);
		
		JLabel lblNewLabel_8 = new JLabel("Ano:");
		lblNewLabel_8.setBounds(16, 204, 46, 14);
		JPanel.add(lblNewLabel_8);
		
		textField_3 = new JTextField();
		textField_3.setBounds(72, 201, 86, 20);
		JPanel.add(textField_3);
		textField_3.setColumns(10);
		
		JLabel lblNewLabel_9 = new JLabel("Cor:");
		lblNewLabel_9.setBounds(16, 229, 46, 14);
		JPanel.add(lblNewLabel_9);
		
		textField_5 = new JTextField();
		textField_5.setBounds(72, 226, 86, 20);
		JPanel.add(textField_5);
		textField_5.setColumns(10);
		
		JLabel lblImg = new JLabel("");
		lblImg.setIcon(new ImageIcon("C:\\Users\\Julia\\Downloads\\carroVerEsse.png"));
		lblImg.setLabelFor(lblImg);
		lblImg.setForeground(Color.CYAN);
		lblImg.setBackground(Color.YELLOW);
		lblImg.setBounds(176, 139, 105, 107);
		JPanel.add(lblImg);
		
		JLabel lblNewLabel_10 = new JLabel("New label");
		lblNewLabel_10.setIcon(new ImageIcon("C:\\Users\\Julia\\Downloads\\motoImagem.png"));
		lblNewLabel_10.setBounds(311, 139, 96, 107);
		JPanel.add(lblNewLabel_10);
	}
}

