import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.border.BevelBorder;
import javax.swing.SwingConstants;
import javax.swing.JTextPane;
import javax.swing.JEditorPane;
import java.awt.SystemColor;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class tela03 extends JFrame {

	private JPanel contentPane;
	private JTextField txtDias;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					tela03 frame = new tela03();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public tela03() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\Julia\\Downloads\\carroVerEsse.png"));
		lblNewLabel_1.setBounds(37, 49, 102, 100);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel = new JLabel("Carro Escolhido");
		lblNewLabel.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 20));
		lblNewLabel.setBounds(136, 13, 177, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_2 = new JLabel("Modelo: Fiat Mobi");
		lblNewLabel_2.setBounds(37, 161, 119, 14);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Ano: 2021");
		lblNewLabel_3.setBounds(37, 186, 119, 14);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblCorVermelho = new JLabel("Cor: Vermelho");
		lblCorVermelho.setBounds(37, 211, 102, 14);
		contentPane.add(lblCorVermelho);
		
		JLabel lblNewLabel_4 = new JLabel("5 Lugares");
		lblNewLabel_4.setBounds(37, 236, 82, 14);
		contentPane.add(lblNewLabel_4);
		
		JEditorPane dtrpnOVeculoIntegra = new JEditorPane();
		dtrpnOVeculoIntegra.setBounds(179, 188, 242, 62);
		contentPane.add(dtrpnOVeculoIntegra);
		dtrpnOVeculoIntegra.setText("O ve\u00EDculo integra a categoria C4, de carros com motor 1.0, c\u00E2mbio manual, ar condicionado, dire\u00E7\u00E3o hidr\u00E1ulica, vidros el\u00E9tricos, air bag e freio ABS. \u00D3timo para proporcionar momentos incr\u00EDveis e inesqueciveis para voc\u00EA.");
		
		JLabel lblNewLabel_5 = new JLabel("Pre\u00E7o do aluguel por diaria:");
		lblNewLabel_5.setBounds(179, 49, 161, 14);
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("R$ 50,00");
		lblNewLabel_6.setForeground(Color.RED);
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_6.setBounds(339, 39, 95, 31);
		contentPane.add(lblNewLabel_6);
		
		JTextPane txtpnQuantidadeDeDias = new JTextPane();
		txtpnQuantidadeDeDias.setBackground(SystemColor.control);
		txtpnQuantidadeDeDias.setText("Insira a quantidade de dias que voc\u00EA ira utilizar o carro:");
		txtpnQuantidadeDeDias.setBounds(179, 74, 143, 34);
		contentPane.add(txtpnQuantidadeDeDias);
		
		txtDias = new JTextField();
		txtDias.setBounds(326, 85, 98, 20);
		contentPane.add(txtDias);
		txtDias.setColumns(10);{
			
		}
		
		JButton btnNewButton_1 = new JButton("Clique para ver o total a pagar");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int num =  Integer.parseInt(txtDias.getText());
				int result = num*50;
				
				JOptionPane.showMessageDialog(null, "Total a pagar: " + result);
			}
		});
		
		btnNewButton_1.setBounds(179, 119, 242, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton = new JButton("Ir para a p\u00E1gina de pagamento");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new tela04 () .setVisible(true);
			}
		});
		btnNewButton.setBounds(179, 147, 242, 23);
		contentPane.add(btnNewButton);
		
	}
}